const World = require('./World');

module.exports = class Normal extends World {
	constructor(options) {
		super(options);
	}
};
