module.exports = {
	SETUP: 1 << 1,
	PLAY: 1 << 2
};
