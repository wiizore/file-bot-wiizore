module.exports = (player, index) => {
	if (player.index == index)
		throw new Error('[⚜️] ➜ 𝗕𝗮̣𝗻 𝗸𝗵𝗼̂𝗻𝗴 𝘁𝗵𝗲̂̉ 𝘁𝘂̛̣ 𝗰𝗵𝗼̣𝗻 𝗯𝗮̉𝗻 𝘁𝗵𝗮̂𝗻 𝗰𝘂̉𝗮 𝗺𝗶̀𝗻𝗵 ❌');
	return index;
};
